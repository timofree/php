<?php
return [
 'db' => [
 'host' => 'localhost',
 'dbname' => 'libros',
 'charset' => 'utf8',
 'user' => 'root',
 'password' => ''
 ]
];