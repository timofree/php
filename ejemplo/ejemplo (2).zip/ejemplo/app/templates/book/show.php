<!DOCTYPE html>
<html lang="es">
<head>
 <meta charset="UTF-8">
 <title><?= $book['title'] ?></title>
</head>
<body>
<h1><?= $book['title'] ?></h1>
<h2><?= $book['author'] ?></h2>
<p><?= $book['description'] ?></p>
</body>
</html>