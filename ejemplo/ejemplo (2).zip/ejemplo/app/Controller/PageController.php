<?php
namespace ejemplo\Bookstore\Controller;
class PageController
{
 public function index()
 {
 echo "¡Bienvenido!";
 }
 public function about()
 {
 echo "Web desarrollada por...";
 }
}